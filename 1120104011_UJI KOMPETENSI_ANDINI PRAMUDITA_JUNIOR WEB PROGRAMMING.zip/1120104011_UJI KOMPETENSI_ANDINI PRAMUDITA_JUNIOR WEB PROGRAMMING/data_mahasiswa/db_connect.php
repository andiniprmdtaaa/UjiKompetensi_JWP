<?php

$db_connect = mysqli_connect("localhost", "root", "", "ujikom_jwp");

// Cek koneksi
if (!$db_connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>
