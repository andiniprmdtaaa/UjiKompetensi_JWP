<form action="" method="post">
    <label for="npm">NPM:</label>
    <input type="text" name="npm"><br><br>

    <label for="nama">Nama:</label>
    <input type="text" name="nama"><br><br>

    <label for="tempat_lahir">Tempat Lahir: </label>
    <input type="text" name="tempat_lahir"><br><br>

    <label for="tanggal_lahir">Tanggal Lahir: </label>
    <input type="date" name="tanggal_lahir"><br><br>

    <label for="nama">Prodi:</label>
    <input type="text" name="prodi"><br><br>

    <input type="submit" value="Submit" name="proses">
</form>

<?php
include "db_connect.php";

if(isset($_POST['proses'])){
    $query = "INSERT INTO nama_mahasiswa SET
    npm = '$_POST[npm]',
    nama = '$_POST[nama]',
    tempat_lahir = '$_POST[tempat_lahir]',
    tanggal_lahir = '$_POST[tanggal_lahir]',
    prodi = '$_POST[prodi]'";

    if(mysqli_query($db_connect, $query)) {
        echo "Data Mahasiswa telah tersimpan";
    } else {
        echo "Error: " . mysqli_error($db_connect);
    }
}
?>
