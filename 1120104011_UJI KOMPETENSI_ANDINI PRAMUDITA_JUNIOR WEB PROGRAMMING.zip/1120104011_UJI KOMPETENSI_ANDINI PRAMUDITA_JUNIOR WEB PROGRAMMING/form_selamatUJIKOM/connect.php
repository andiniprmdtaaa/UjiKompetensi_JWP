<?php
	$nik = $_POST['nik'];
	$nama = $_POST['nama'];
	$tempat_lahir = $_POST['tempat_lahir'];
	$tanggal_lahir = $_POST['tanggal_lahir'];
	$jenkel = $_POST['jenkel'];
	$alamat = $_POST['alamat'];
	$agama = $_POST['agama'];


	// Database connection
	$conn = new mysqli('localhost','root','','ujikom_jwp');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into form_registrasi (nik, nama, tempat_lahir, tanggal_lahir, jenkel, alamat, agama) values(?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssi", $nik, $nama, $tempat_lahir, $tanggal_lahir, $jenkel, $alamat, $agama);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>