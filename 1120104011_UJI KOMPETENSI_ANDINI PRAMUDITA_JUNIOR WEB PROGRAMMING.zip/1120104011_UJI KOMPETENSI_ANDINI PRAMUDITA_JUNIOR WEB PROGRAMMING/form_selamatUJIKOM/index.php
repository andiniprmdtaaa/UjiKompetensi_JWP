<!DOCTYPE html>
<html>
  <head>
    <title>INPUT BIODATA</title>
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  </head>
  <body>
    <div class="container">
      <div class="row col-md-6 col-md-offset-3">
        <div class="panel panel-primary">
          <div class="panel-heading text-center">
            <h1>Registration Form</h1><br>
            <h3>Selamat Mengikuti Uji Kompetensi pada Skema Programmer</h3>
          </div>
          <div class="panel-body">
            <form action="connect.php" method="post">
              <div class="form-group">
                <label for="nik">NIK</label>
                <input
                  type="text"
                  class="form-control"
                  id="nik"
                  name="nik"
                />
              </div>
              <div class="form-group">
                <label for="lastName">Nama</label>
                <input
                  type="text"
                  class="form-control"
                  id="nama"
                  name="nama"
                />
              </div>
              <div class="form-group">
                <label for="tempat_lahir">Tempat Lahir</label>
                <input
                  type="text"
                  class="form-control"
                  id="tempat_lahir"
                  name="tempat_lahir"
                />
              </div>
              <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input
                  type="text"
                  class="form-control"
                  id="tanggal_lahir"
                  name="tanggal_lahir"
                />
              </div>
              <div class="form-group">
                <label for="jenkel">Jenis Kelamin</label>
                <div>
                  <label for="perempuan" class="radio-inline"
                    ><input
                      type="radio"
                      name="jenkel"
                      value="perempuan"
                      id="jenkel"
                    />Perempuan</label
                  >
                  <label for="lakilaki" class="radio-inline"
                    ><input
                      type="radio"
                      name="jenkel"
                      value="lakilaki"
                      id="lakilaki"
                    />Laki-Laki</label
                  >
                </div>
              </div>
              <div class="form-group">
                <label for="alamat">Alamat</label>
                <input
                  type="text"
                  class="form-control"
                  id="alamat"
                  name="alamat"
                />
              </div>
              <div class="form-group">
                <label for="password">Agama</label>
                <input
                  type="text"
                  class="form-control"
                  id="agama"
                  name="agama"
                />
              </div>
              <input type="submit" class="btn btn-primary" />
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
      <input type="cancel" class="btn btn-primary" />
</div>
  </body>
</html>
