<!DOCTYPE html>
<html>
<head>
    <title>Menghitung Luas Segitiga</title>
</head>
<body>
    <h1>HITUNG LUAS SEGITIGA</h1>
    <form action="" method="POST">
        <table>
            <tr>
                <td>Alas:</td>
                <td><input type="number" name="alas" step="any" required></td>
            </tr>
            <tr>
                <td>Tinggi:</td>
                <td><input type="number" name="tinggi" step="any" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Hitung"></td>
            </tr>
        </table>
    </form>
    <?php
    if (isset($_POST['submit'])) {
        // Mendapatkan input dan melakukan sanitasi
        $alas = isset($_POST['alas']) ? (float) $_POST['alas'] : 0;
        $tinggi = isset($_POST['tinggi']) ? (float) $_POST['tinggi'] : 0;

        // Menghitung luas segitiga
        $luas_segitiga = 0.5 * $alas * $tinggi;

        // Menampilkan hasil
        echo "Diketahui:<br />";
        echo "Alas = $alas<br />";
        echo "Tinggi = $tinggi<br />";
        echo "Maka Luas Segitiga adalah 1/2 x ($alas) x ($tinggi) = $luas_segitiga";
    }
    ?>
</body>
</html>
